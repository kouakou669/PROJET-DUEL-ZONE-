# Login-and-Registration-Form
### Simple Login and registration form using HTML, CSS  and PHP 

This repo provides a simple login and registration form pages and the connection of frontend with backend. <br/>
This module is often required in several projects of web development. <br/>

1. Download this repo and store in Xampp folder
1. Load the sql file in phpmyadmin with DB details given in Dbname.sql
1. Open the folder in localhost

